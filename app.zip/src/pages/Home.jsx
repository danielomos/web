import React from "react";
import { Link } from "react-router-dom";
import Home1Page from "./Home1";
const Home = () => {
  return (
<Home1Page />
  );
};
export default Home;
